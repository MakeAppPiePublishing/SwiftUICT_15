//
//  UnitOfMeasure.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import Foundation


import Foundation

enum UnitOfMeasure:String,CaseIterable{
    case liter = "L"
    case mililiter = "ml"
    case gram = "gr"
    case kilogram = "kg"
    case each = "ea"
    case dozen = "dz"
    case gross = "gross"
    case na = "N/A"
    case minutes = "min"
    case hours = "hr"
    case days = "day"
}
