//
//  Ingredients View.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct IngredientsView: View {
    
    ///The ingredients instance for acessing the model methods
    @Bindable var ingredients:Ingredients
    
    
    // flags for launching sheets
    @State private var addIngredient:Bool = false
    @State private var editIngredient:Bool = false
    
    // The selected ingredient
    @State private var selection:Ingredient = .blank
        
    func filteredIngredients(category:IngredientCategory)->[Ingredient]{
        ingredients.table.filter{$0.category == category}
    }
    
    var sortedCategories:[IngredientCategory]{
        IngredientCategory.allCases.sorted{$0.rawValue < $1.rawValue}
    }
    
    var body: some View {
        VStack(alignment:.leading){
            
            // The add button bar
            HStack{
               Spacer()
                Button{
                    addIngredient = true
                } label: {
                    Label("Add Ingredient", systemImage: "plus.rectangle")
                        .imageScale(.large)
                }
                .appButtonStyleModifier(backgroundColor: .surf)
                .padding()
            }
            .background(.ultraThinMaterial)
            
            // The headings for the list
            HStack{
                Text("Ingredient")
                    .leftFixedStyle()
                Text("UoM")
                    .centerFixedStyle()
                Text("Identifier")
                    .rightFixedStyle()
                Spacer()
                
            }
            .font(.headline)
            .padding(18)
            .background(.regularMaterial)
            
            //The list of ingredients. For selection I use a button.
            List{
                ForEach(sortedCategories, id:\.self){ category in
                    Section{
                        ForEach(filteredIngredients(category: category)){ ingredient in
                            Button{
                                selection = ingredient
                                editIngredient = true
                            }label:{
                                IngredientRowView(ingredient: ingredient)
                                    .rowStyleModifier
                                    .padding(.leading)
                            }
                        }
                    }header:{
                        Text(category.rawValue)
                    }
                }

            }
            .gradientBackground
            .sheet(isPresented:$editIngredient){
                IngredientsChangeView(ingredients: ingredients, selectedIngredient: $selection, isPresented: $editIngredient)
                    
            }
            .sheet(isPresented:$addIngredient){
                IngredientsAddView(ingredients: ingredients, isPresented: $addIngredient)
            }
        }
    }
}

#Preview {
    @Previewable @State var ingredients = Ingredients()
    IngredientsView(ingredients: ingredients)
}
