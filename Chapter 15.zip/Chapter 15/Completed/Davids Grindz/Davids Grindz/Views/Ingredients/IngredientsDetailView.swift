//
//  IngredientsDetailView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

import SwiftUI

struct IngredientsDetailView: View {
    @Binding  var ingredient:Ingredient
    var isEditing:Bool = false
    var body: some View {
        VStack(alignment:.leading){
            
            TextStringInputField(value: $ingredient.itemName, isEditing: isEditing)
                .inputTitleLabelStyle(label: "Ingredient Name")
            CategoryPicker(category: $ingredient.category,isEditing: isEditing)
                .inputTitleLabelStyle(label: "Ingredient Category")
            UoMPicker(uom: $ingredient.uom, isEditing: isEditing)
                .inputTitleLabelStyle(label: "Ingredient Unit of Measure")
        }
    }
}

#Preview {
    @Previewable @State var ingredient = Ingredients().table[5]
    IngredientsDetailView(ingredient: $ingredient,isEditing: false)
}
