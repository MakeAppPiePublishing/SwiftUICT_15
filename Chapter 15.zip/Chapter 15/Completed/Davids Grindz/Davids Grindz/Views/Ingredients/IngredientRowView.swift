//
//  IngredientRowView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct IngredientRowView: View {
    var ingredient:Ingredient

    var body: some View {
        HStack{
            Text(ingredient.itemName)
                .leftFixedStyle(width:250)
            Text(ingredient.uom.rawValue)
                .centerFixedStyle()
            Text(ingredient.id,format:.number.grouping(.never))
                .rightFixedStyle()
        }
    }
}

#Preview {
    @Previewable @State var ingredient = Ingredients().table[5]
    IngredientRowView(ingredient:ingredient)
}
