//
//  IngredientsAddView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

import SwiftUI

struct IngredientsAddView: View {
    @Bindable var ingredients:Ingredients
    @Binding var isPresented:Bool
    @State private var ingredient:Ingredient = .blank
    
    var body: some View {
        VStack{
            Text("Add an Ingredient")
                .surfboardTitle
                .surfboardBackground
            IngredientsDetailView(ingredient: $ingredient, isEditing: true)
                .padding(.bottom)
            Divider()
            Spacer()
            HStack{
                Spacer()
                Button("Add"){
                    ingredients.addIngredient(ingredient: ingredient)
                    isPresented = false
                }
                .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                Button("Cancel"){
                    isPresented = false
                }
                .appButtonStyleModifier(backgroundColor: .sunset)
                Spacer()
            }
        }
        .padding()
    }
}

#Preview {
    @Previewable @State var ingredients = Ingredients()
    @Previewable @State var isPresented:Bool = true
    IngredientsAddView(ingredients: ingredients, isPresented: $isPresented)
}
