//
//  IngredientsChangeView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//



import SwiftUI

struct IngredientsChangeView: View {
    @Bindable var ingredients:Ingredients
    @Binding var selectedIngredient:Ingredient
    @Binding var isPresented:Bool
    @State private var ingredient:Ingredient = .blank
    
    var body: some View {
        VStack(alignment:.leading){
            Text("Update Ingredient")
                .surfboardTitle
                .surfboardBackground
            IngredientsDetailView(ingredient: $ingredient, isEditing: true)
                .padding(.bottom)
            Divider()
            Spacer()
            HStack{
                Spacer()
                Button("Update"){
                    ingredients.updateIngredient(ingredient: ingredient)
                    isPresented = false
                }
                .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                Button("Cancel"){
                    isPresented = false
                }
                .appButtonStyleModifier(backgroundColor: .sunset)
                Spacer()
            }
        }
        .padding()
        .gradientBackground
        .onAppear{
            ingredient = selectedIngredient
        }
    }
}

#Preview {
    @Previewable @State var ingredients = Ingredients()
    @Previewable @State var selectedIngredient = Ingredients().table[5]
    @Previewable @State var isPresented:Bool = true
    IngredientsChangeView(ingredients:ingredients, selectedIngredient: $selectedIngredient, isPresented: $isPresented)
}
