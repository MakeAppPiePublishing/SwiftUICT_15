//
//  CheckBoxView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct CheckboxView:View{
    var label:String = ""
    @Binding var isOn:Bool
    var isEditing:Bool = true
    var body: some View{
        HStack{
            Button{
                isOn.toggle()
            } label: {
                Image(systemName: isOn ? "x.square" : "square" )
            }
            Spacer()
        }
        .controlViewStyle(label: label, isEditing: isEditing)
    }
}

#Preview{
    @Previewable @State var isOn:Bool = false
    CheckboxView(label:"Action",isOn:$isOn,isEditing:false)
}
