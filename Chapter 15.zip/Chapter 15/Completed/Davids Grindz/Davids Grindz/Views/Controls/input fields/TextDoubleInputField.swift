//
//  TextDoubleInputView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct TextDoubleInputField:View{
    var label:String = ""
    @Binding var number:Double
    var isEditing:Bool = true
    var formatter:NumberFormatter{
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 3
        formatter.maximumFractionDigits = 3
        return formatter
    }
    var body:some View{
        HStack(alignment: .firstTextBaseline){
            TextField(label, value: $number, formatter: formatter)
                .multilineTextAlignment(.trailing)
        }
        .controlViewStyle(label: label, isEditing: isEditing)
    }
}

#Preview{
    TextDoubleInputField(label:"A number",number: .constant(42.34556), isEditing: true)
}
