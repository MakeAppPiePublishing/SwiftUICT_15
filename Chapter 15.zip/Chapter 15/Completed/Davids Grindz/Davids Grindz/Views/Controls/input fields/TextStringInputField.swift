//
//  TextStringInputView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

import SwiftUI

struct TextStringInputField:View{
    var label:String = ""
    @Binding var value:String
    var isEditing:Bool = true
    
    var body:some View{
            HStack(alignment: .firstTextBaseline){
                TextField(label, text: $value)
                Spacer()
            }
            .controlViewStyle(label: label, isEditing: isEditing)
    }
}

#Preview{
    TextStringInputField(value: .constant("Pizza"), isEditing: true)
}
