//
//  TextIntInputView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct TextIntInputField:View{
    var label:String = ""
    @Binding var number:Int
    var isEditing:Bool = true
    var formatter:NumberFormatter{
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 0
        return formatter
    }
    var body:some View{
        HStack(alignment: .firstTextBaseline){
           
            TextField(label, value: $number, formatter: formatter)
            Spacer()
        }
        .controlViewStyle(label: label, isEditing: isEditing)
    }
}

#Preview{
    TextIntInputField(number: .constant(42), isEditing: false)
}
