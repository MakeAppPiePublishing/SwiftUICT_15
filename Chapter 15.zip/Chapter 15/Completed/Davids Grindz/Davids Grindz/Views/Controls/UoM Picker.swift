//
//  UoM Picker.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct UoMPicker:View{
    var label:String = ""
    @Binding var uom:UnitOfMeasure
    var isEditing:Bool = true
    var body: some View{
        if isEditing{
            Picker(label, selection: $uom) {
                ForEach(UnitOfMeasure.allCases, id:\.self){ uom in
                    Text(uom.rawValue).tag(uom)
                }
            }
            .controlViewStyle(label: label, isEditing: isEditing)
        } else{
                Text(uom.rawValue)
        }
   }
}

#Preview(body: {
    @Previewable @State var uom:UnitOfMeasure = .gross
    UoMPicker(label:"Unit of Measure",uom:$uom,isEditing: false)
})

