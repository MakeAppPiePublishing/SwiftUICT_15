//
//  CategoryPIcker.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//



import SwiftUI

struct CategoryPicker:View{
    var label:String = ""
    @Binding var category:IngredientCategory
    var isEditing:Bool = true
    var body: some View{
        Picker(label, selection: $category ) {
            ForEach(IngredientCategory.allCases, id:\.self){ category in
                Text(category.rawValue).tag(category)
            }
        }
        .controlViewStyle(label: label, isEditing: isEditing)
   }
}


#Preview {
    @Previewable @State var category:IngredientCategory = .pizza
    CategoryPicker(category: $category,isEditing:true)
}
