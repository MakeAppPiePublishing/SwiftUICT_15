//
//  IngredientsPicker.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

//
//  UoM Picker.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct IngredientsPicker:View{
    var label:String = ""
    @Binding var ingredient:Ingredient
    @Environment(Ingredients.self) var ingredients:Ingredients
    var isEditing:Bool = true
    //var ingredients:[Ingredient]{Ingredients().table}
    var body: some View{
        if isEditing{
            Picker(label, selection: $ingredient) {
                ForEach(ingredients.table){ ingredient in
                    Text(ingredient.itemName).tag(ingredient)
                }
                
            }
            .controlViewStyle(label: label, isEditing: isEditing)
        } else {
            Text(ingredient.itemName)
            //    .controlViewStyle(label: label, isEditing: isEditing)
        }
        
   }
}

#Preview(body: {
    @Previewable @State var ingredients = Ingredients()
    @Previewable @State var ingredient:Ingredient = Ingredients().table[2]
    IngredientsPicker(label:"Ingredient",ingredient:$ingredient,isEditing: false)
        .environment(ingredients)
})

