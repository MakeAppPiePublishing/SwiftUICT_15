//
//  ContentView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI
//
struct ContentView: View {
    
    //Source of all models. 
    @Bindable var ingredients:Ingredients
    @State private var recipes:Recipes = Recipes()
    @State private var recipeSteps:RecipeSteps = RecipeSteps()
    
    var body: some View {
        TabView{
            Tab {
                RecipeView(recipes: recipes, steps: recipeSteps)
            } label: {
                Label {
                    Text("Recipe")
                } icon: {
                    Image(systemName:"text.rectangle.page")
                }
            }

            Tab{
                IngredientsView(ingredients: ingredients)
            } label:{
                Label {
                    Text("Ingredients")
                } icon: {
                    Image(systemName:"list.bullet.clipboard")
                }
            }
        }
    }
}

#Preview {
    @Previewable @State var ingredients:Ingredients = Ingredients()
    ContentView(ingredients:ingredients)
        .environment(ingredients)
}
