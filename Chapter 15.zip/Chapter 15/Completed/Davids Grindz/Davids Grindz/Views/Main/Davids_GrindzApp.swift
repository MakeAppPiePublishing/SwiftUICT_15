//
//  Davids_GrindzApp.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

@main
struct Davids_GrindzApp: App {
    @State private var ingredients:Ingredients = Ingredients()
    var body: some Scene {
        WindowGroup {
            ContentView(ingredients:ingredients)
                .environment(ingredients)
        }
    }
}
