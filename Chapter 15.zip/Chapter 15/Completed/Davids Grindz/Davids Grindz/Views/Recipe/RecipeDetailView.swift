//
//  RecipeDetailView03.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/3/25.
//

import SwiftUI

struct RecipeDetailView: View {
    @Binding var id:Int
    @Bindable var recipes:Recipes
    @Bindable var steps:RecipeSteps
    

    ///the recipe displayed
    @State private var recipe:Recipe = .blank
    
    ///the flag for launching the editing sheet for the recipe header
    @State private var isEditing:Bool = false
    
    var body: some View {
        VStack{
//Header-----------------
            Text(recipe.name)
                .surfboardTitle
                .surfboardBackground
                .padding(.top,10)
            HStack{
                Text(recipe.category.rawValue)
                Spacer()
                Text("Yield:")
                Text(recipe.yield,format:.number.precision(.fractionLength(3)))
                Text(recipe.uom.rawValue)
            }
            .foregroundStyle(.sky)
            .font(.headline)
            .padding(10)
            .background(.surf, in:Surfboard().rotation(Angle(degrees: 180)))

//Detail -------------------
            RecipeStepsView(recipeID: $id, steps: steps)
                .padding(.leading,40)
            Spacer()
        }
        .gradientBackground
        

// Appear and change ------------------
        .onAppear{
            recipe = recipes.recipe(id: id)
        }
        .onChange(of:id){
            recipe = recipes.recipe(id: id)
        }
        .onChange(of:isEditing){
            recipe = recipes.recipe(id: id)
        }
        
// toolbar ---------------
        .toolbar{
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button{
                    isEditing = true
                }label:{
                    Image(systemName:"pencil.and.list.clipboard")
                        .symbolRenderingMode(.palette)
                        .shadow(radius: 1.0)
                }
                .appButtonStyleModifier(backgroundColor: .surf)
                .padding()
            }
            
        }

//Sheet ---------
        .sheet(isPresented:$isEditing){
            RecipeEditView(isEditing:$isEditing,recipe:recipe,recipes:recipes)
                .frame(maxWidth:1000)
        }
        
    }
    
}

#Preview {
    RecipeDetailView(id:.constant(1),recipes:Recipes(), steps: RecipeSteps())
}
