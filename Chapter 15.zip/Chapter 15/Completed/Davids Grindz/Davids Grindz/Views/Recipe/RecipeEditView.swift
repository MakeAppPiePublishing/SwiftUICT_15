//
//  RecipeEntryView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/4/25.
//

// -- As a reminder of what we have to set up here
//var id:Int
//var name:String
//var yield:Double
//var uom:UnitOfMeasure
//var category:IngredientCategory

import SwiftUI


struct RecipeEditView: View {
    @Binding var isEditing:Bool
    @State var recipe:Recipe
    @Bindable var recipes:Recipes
    
    
    @State private var name:String = ""
    @State private var yield:Double = 0.0
    @State private var uom:UnitOfMeasure = .na
    @State private var category:IngredientCategory = .na
    
    func updateView(){
        name = recipe.name
        yield = recipe.yield
        uom = recipe.uom
        category = recipe.category
    }
    
    var body: some View {
        VStack(alignment:.leading){
            Text("Edit Recipe")
                .surfboardTitle
                .surfboardBackground
                .padding(.bottom,10)
            TextField("Recipe Name", text: $name, prompt: Text("Recipe Name"))
                .textFieldBorder
                .inputTitleLabelStyle(label: "Recipe Name")
                
                HStack{
                    TextField("Yield", value: $yield, format: .number.precision(.fractionLength(3)), prompt: Text("Yield"))
                        .multilineTextAlignment(.trailing)
                    UoMPicker(uom: $uom)
                }
                .textFieldBorder
                .inputTitleLabelStyle(label: "Recipe Amount")
                
            CategoryPicker(category: $category)
            .inputTitleLabelStyle(label: "Food Category")
            
            Spacer()
            HStack{
                Button("Update"){
                    let updatedRecipe = Recipe(id: recipe.id, name: name, yield: yield, uom: uom, category: category)
                    recipe = Recipe(id: recipe.id, name: name, yield: yield, uom: uom, category: category)
                    recipes.updateRecipe(recipe: updatedRecipe)
                    isEditing = false
                  
                }
                .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                Button("Cancel"){
                    isEditing = false
                  
                }
                .appButtonStyleModifier(backgroundColor: .sunset)
            }
            .padding()
            
        }
        .sheetBackground
        .onAppear{
                updateView()
        }
        .onChange(of:isEditing){
            updateView()
        }
    }
}

//#Preview{
//    @Previewable @State var recipes:Recipes = Recipes()
//    @Previewable @State var isEditing:Bool = false
//    @Previewable @State var recipe:Recipe = .blankRecipe
//    RecipeEditView(isEditing:$isEditing,recipe:recipe,recipes:recipes)
//}
