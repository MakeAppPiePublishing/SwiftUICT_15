//
//  RecipeStepsRowUpdateView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/5/25.
//
//
//  RecipeStepsRowAddView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/5/25.
//

import SwiftUI

struct RecipeStepsRowUpdateView: View {
    
    
    @Binding var rowID:Int
    @Bindable var steps:RecipeSteps
    @Binding var displaySheet:Bool
    
    
    /// determine the rowtype to display.
    /// `@Binding` for add and insert, prohibit changes to type in edit and make this `var`. In calling function this lets you set the last type used.
    @Binding var isAction:Bool
    
    
    // temporary storage for the recipe
    @State private var  step:RecipeStep = .blank
    @State private var ingredients = Ingredients()
    @State private var ingredient:Ingredient = .blank
    @State private var itemCode:Int = -1
    @State private var quantity:Double = 0.0
    @State private var actions:String = ""
    @State private var uom:UnitOfMeasure = .na
    
    //error trapping
    @State private var recordFound:Bool = true
    
    var body: some View {
        VStack(alignment:.leading){
            
            Text("Update a " + (isAction ? "Action" : "Ingredient"))
                .surfboardTitle
                .surfboardBackground
            if isAction{
                TextEditor(text: $actions)
                    .textFieldBorder
                    .inputTitleLabelStyle(label: "Instruction Step For Recipe")
            } else {
                
                    IngredientsPicker(label: "", ingredient: $ingredient)
                    .inputTitleLabelStyle(label: "Ingredient")

                HStack{
                    TextField("Quantity", value: $quantity, format: .number.precision(.fractionLength(3)), prompt: Text("Quantity"))
                        .multilineTextAlignment(.trailing)
                        
                    Text(uom.rawValue)
                        
                }
                .textFieldBorder
                .inputTitleLabelStyle(label: "Quantity")
                
                TextField("",text: $actions)
                    .textFieldBorder
                    .inputTitleLabelStyle(label: "Comments")
            }
            Spacer()
            HStack{
                
                Button("Update"){
                    step = RecipeStep(recipeID: step.recipeID,rowID:step.rowID, itemCode: itemCode, quantity: quantity, actions: actions,isAction:isAction)
                    steps.updateRow(recipeStep: step)
                    displaySheet = false
                }
                    .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                
                Button("Cancel"){
                    displaySheet = false
                }
                    .appButtonStyleModifier(backgroundColor: .sunset)
               
            }
        }
        .sheetBackground
        
        .onChange(of:ingredient){
            refreshView()
        }
        
        .onAppear{
            // get the step
            if let step = steps.step(id:rowID){
                // get the associated ingredient if there
                self.step = step
                ingredient = ingredients.ingredient(id:step.itemCode)
                refreshView()
            }
        }
    }
    
    func refreshView(){
        itemCode = ingredient.id
        quantity = step.quantity
        actions = step.actions
        uom = ingredient.uom
        isAction = step.isAction
        
    }
        
}

#Preview {
    @Previewable @State var rowID:Int = 1002
    @Previewable @State var isAction:Bool = false
    @Previewable @State var addAnother:Bool = false
    RecipeStepsRowUpdateView(rowID: $rowID, steps: RecipeSteps(), displaySheet: .constant(true), isAction: $isAction)
}
