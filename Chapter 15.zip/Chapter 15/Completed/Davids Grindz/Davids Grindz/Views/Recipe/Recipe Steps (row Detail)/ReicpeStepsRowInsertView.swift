//
//  ReicpeStepsRowInsertView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/7/25.
//

import SwiftUI

struct RecipeStepsRowInsertView: View {
    
    var baseStep:RecipeStep
    @Bindable var steps:RecipeSteps
    @Binding var displaySheet:Bool
    
    
    /// determine the rowtype to display.
    /// `@Binding` for add and insert, prohibit changes to type in edit and make this `var`. In calling function this lets you set the last type used.
    @Binding var isAction:Bool
    
    
    // temporary storage for the recipe
    @State private var ingredients = Ingredients()
    @State private var ingredient:Ingredient = .blank
    @State private var itemCode:Int = -1
    @State private var quantity:Double = 0.0
    @State private var actions:String = ""
    @State private var uom:UnitOfMeasure = .na
    
    
    var body: some View {
        VStack(alignment:.leading){
            
            Text("Insert a" + (isAction ? "Action" : "Ingredient"))
                .surfboardTitle
                .surfboardBackground
            Picker("Row Type", selection: $isAction) {
                Text("Ingredient").tag(false)
                Text("Action").tag(true)
            }
            .pickerStyle(.segmented)
            .appButtonStyleModifier(backgroundColor: .sky)
            if isAction{
                TextEditor(text: $actions)
                    .textFieldBorder
                    .inputTitleLabelStyle(label: "Instruction step for recipe")
            } else {
               
                    IngredientsPicker(label: "", ingredient: $ingredient)
                    .inputTitleLabelStyle(label: "Ingredient for Recipe")
               
                HStack{
                    TextField("Quantity", value: $quantity, format: .number.precision(.fractionLength(3)), prompt: Text("Quantity"))
                        .multilineTextAlignment(.trailing)
                    Text(uom.rawValue)
                        
                }
                .textFieldBorder
                .inputTitleLabelStyle(label: "Amount")
                
                TextField("",text: $actions)
                    .textFieldBorder
                    .inputTitleLabelStyle(label: "Comments")
                
            }
            Spacer()
            HStack{
                
                Button("Insert"){
                    let insertedStep = RecipeStep(recipeID: baseStep.recipeID, itemCode: itemCode, quantity: quantity, actions: actions, isAction: isAction)
                    steps.insertRow(after: baseStep, with: insertedStep)
                    displaySheet = false
                    
                }
                    .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                
                Button("Cancel"){
                    displaySheet = false
                }
                    .appButtonStyleModifier(backgroundColor: .sunset)
               
            }
        }
        .sheetBackground
        .onChange(of:ingredient){
            itemCode = ingredient.id
            uom = ingredient.uom
        }
    }
        
}

//#Preview {
//    RecipeStepsRowInsertView(baseStep: <#T##RecipeStep#>, steps: <#T##RecipeSteps#>, displaySheet: <#T##Bool#>, isAction: <#T##Bool#>)
//}
