//
//  RecipeStepsView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

import SwiftUI


struct RecipeStepsView: View {
    
    
    @Binding var recipeID:Int
    @Bindable var steps:RecipeSteps
    @Environment(Ingredients.self) var ingredientsModel: Ingredients
    
    @State private var isCommercialRecipe:Bool = true
    @State private var isEditingStep:Bool = false
    
    // Variable for showing sheets
    let noSelectedRow = -1
    @State private var displayRowID:Int = -1 // identifies the row
    @State private var selectedRow:RecipeStep = .blank
    @State private var addingRow:Bool = false
    @State private var updatingRow:Bool = false
    @State private var insertingRow:Bool = false
    
    //status for editing and adding sheet methods
    @State private var isAction = false // show action or recipe
    @State private var addAnother = false // immeditely launch back into new sheet
    @State private var statusMessage:String = "" // Status message used for debugging
    
    
    func ingredient(itemCode:Int)->Ingredient{
        if let ingredient = ingredientsModel.table.first(where: {$0.id == itemCode}){
            return ingredient
        } else {
            return Ingredient.blank
        }
    }
    
    func ingredientStepGridRow(step:RecipeStep) -> some View {
        let ingredient = ingredient(itemCode: step.itemCode)
        return    GridRow{
                Text(step.quantity,format:.number.precision(.fractionLength(3)))
                    .gridCellAnchor(.trailing)
                Text(ingredient.uom.rawValue)
                    .gridCellAnchor(.leading)
                Text(ingredient.itemName)
                    .gridCellAnchor(.leading)
                Text(step.actions)
                    .gridCellAnchor(.leading)
                    

            }
    }
    
    func actionStepGridRow(step:RecipeStep) -> some View {
        GridRow{
            Text("")
            Text(step.actions)
                .gridCellColumns(3)
                .gridCellAnchor(.leading)
        }
    }
    
    
    // a recipe with ingredients arranged on top
    @ViewBuilder var homeRecipe:some View{
        ForEach(steps.ingredientSteps(for: recipeID)){ step in
            ingredientStepGridRow(step:step)
                .onTapGesture(count:2){
                        displayRowID = step.id
                        selectedRow = steps.step(id: step.id)
                    
            }
                .stepSelectionStyleModifier(displayRowID: displayRowID, stepID: step.id)
            
        }
        ForEach (steps.actionSteps(for: recipeID)){ step in
       
                actionStepGridRow(step: step)
                .onTapGesture(count:2){
                        displayRowID = step.id
                    selectedRow = steps.step(id: step.id)
                    }
                .stepSelectionStyleModifier(displayRowID: displayRowID, stepID: step.id)
            
        }
    }
    
    // a recipe with ingredients arranged before the actions that use them.
    var commercialRecipe:some View{
        ForEach(steps.allSteps(for: recipeID)){ step in
            if step.isAction {
                actionStepGridRow(step: step)
                    .onTapGesture(count:2){
                            displayRowID = step.id
                        }
                    .stepSelectionStyleModifier(displayRowID: displayRowID, stepID: step.id)
            } else {
                    ingredientStepGridRow(step:step)
                    .onTapGesture(count:2){
                            displayRowID = step.id
                        selectedRow = steps.step(id: step.id)
                        
                }
                    .stepSelectionStyleModifier(displayRowID: displayRowID, stepID: step.id)
            }
            
        }
    }
    var body: some View {
        VStack(alignment:.leading){
            ScrollView{
                Grid{
                    
                    if isCommercialRecipe{
                        commercialRecipe
                    } else {
                        homeRecipe
                    }
                }
            }
        }

//        .onChange(of: displayRowID, { oldValue, newValue in
//            if newValue < 0{
//                statusMessage = "Deselected"
//            } else {
//                statusMessage = "Selected row \(displayRowID.formatted(.number.grouping(.never)))"
//            }
//        })
        
        // show the adding row sheet
        .sheet(isPresented: $addingRow, onDismiss: {
            if addAnother {
                addingRow = true
            }
        }, content: {
            RecipeStepsRowAddView(recipeID: recipeID, steps: steps, displaySheet: $addingRow, isAction: $isAction, addAnother: $addAnother)
        })
        
        .sheet(isPresented: $updatingRow){
            displayRowID = -1 //deselect the row
        }content:{
            RecipeStepsRowUpdateView(rowID: $displayRowID, steps: steps, displaySheet: $updatingRow, isAction: $isAction)
        }
        .sheet(isPresented: $insertingRow){
           RecipeStepsRowInsertView(baseStep: selectedRow, steps: steps, displaySheet: $insertingRow, isAction: $isAction)
        }
        .toolbar{
            ToolbarItemGroup(placement:.navigation){
                //updating and insertion buttons appear upon selection
                if displayRowID > 0{
                    Button{
                        insertingRow = true
                    } label: {
                        Image(systemName:"text.line.last.and.arrowtriangle.forward")
                    }
                    .appButtonStyleModifier(backgroundColor: .surf)
                    
                    Button{
                        updatingRow = true
                    }label:{
                        Image(systemName:"rectangle.and.pencil.and.ellipsis")
                    }
                    .appButtonStyleModifier(backgroundColor: .surf)
                }
                
                // Adding a row
                
                Button{
                    addingRow = true
                }label:{
                    Image(systemName:"text.badge.plus")
                        .symbolRenderingMode(.multicolor)
                }
                .appButtonStyleModifier(backgroundColor: .surf)
                
                //toggle between commercial and home recipe format
                Button{
                    isCommercialRecipe.toggle()
                }label:{
                    Image(systemName: isCommercialRecipe ? "building":"house")
                }
                .appButtonStyleModifier(backgroundColor: .surf)
                .padding(.trailing,10)
                
                
            }
        }
    }
}

#Preview {
    @Previewable @State var recipeID:Int = 2
    @Previewable @State var steps = RecipeSteps()
    @Previewable @State var ingredients = Ingredients()
    RecipeStepsView(recipeID: $recipeID, steps:steps)
        .environment(ingredients)
}
