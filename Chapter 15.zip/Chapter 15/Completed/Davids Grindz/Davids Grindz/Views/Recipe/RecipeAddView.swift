//
//  RecipeAddView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/4/25.
//

// -- As a reminder of what we have to set up here
//var id:Int
//var name:String
//var yield:Double
//var uom:UnitOfMeasure
//var category:IngredientCategory

import SwiftUI


struct RecipeAddView: View {
    @Binding var isAdding:Bool
    @Bindable var recipes:Recipes
    
    @State private var recipe:Recipe = .blank
    @State private var name:String = ""
    @State private var yield:Double = 0.0
    @State private var uom:UnitOfMeasure = .na
    @State private var category:IngredientCategory = .na
    
    func updateView(){
        name = recipe.name
        yield = recipe.yield
        uom = recipe.uom
        category = recipe.category
    }
    
    var body: some View {
        VStack(alignment:.leading){
            Text("Add Recipe")
                .surfboardTitle
                .surfboardBackground
                .padding(.bottom,10)
            TextField("Recipe Name", text: $name)
                .textFieldBorder
                .inputTitleLabelStyle(label: "Recipe Name")
            
            HStack{
                TextField("Yield", value: $yield, format: .number.precision(.fractionLength(3)))
                    .multilineTextAlignment(.trailing)
                UoMPicker(uom: $uom)
            }
            .textFieldBorder
            .inputTitleLabelStyle(label: "Recipe Yield")
            CategoryPicker(category: $category)
                .inputTitleLabelStyle(label: "Food Category")
            
            Spacer()
            HStack{
                Button("Add"){
                    recipes.addRecipe(id: nil, name: name, yield: yield, uom: uom, category: category)
                    isAdding = false
                }
                .appButtonStyleModifier(backgroundColor: .palm)
                Spacer()
                Button("Cancel"){
                    isAdding = false
                }
                .appButtonStyleModifier(backgroundColor: .sunset)
            }
            .padding()
            
        }
        .padding()
        .onAppear{
            updateView()
            uom = category.uom //on first appearce guess at uom from category
        }
    }
}

