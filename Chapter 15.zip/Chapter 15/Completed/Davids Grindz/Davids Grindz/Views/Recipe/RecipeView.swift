//
//  RecipeView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/2/25.
//

import SwiftUI

struct RecipeView: View {
    
    @Bindable var recipes:Recipes
    @Bindable var steps:RecipeSteps
    ///disply flag for adding sheet if `true`
    @State private var isAdding:Bool = false
    
    var body: some View {
        VStack{
            NavigationSplitView {
                Button{
                    isAdding = true
                }label:{
                    Label("Add Recipe" ,systemImage:"plus.rectangle")
                        .fontWeight(.bold)
                }
                .appButtonStyleModifier(backgroundColor: .surf)
                List{
                   
                    ForEach($recipes.table){ recipe in
                        NavigationLink {
                            RecipeDetailView(id:recipe.id, recipes: recipes, steps: steps)
                        } label: {
                            VStack(alignment:.leading){
                                Text(recipe.category.wrappedValue.rawValue)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Text(recipe.name.wrappedValue)
                                
                            }
                        }
                    }
                    
                }
                
            } detail: {
                VStack{
                    Image("Tent")
                        .resizable()
                        .scaledToFit()
                    
                    VStack{
                        HStack{
                            Spacer()
                            Text("Chef David's Grindz")
                                .font(.largeTitle).bold()
                        }
                        .surfboardBackground
                        HStack{
                            Spacer()
                            Text("The Huli Pizza Company recipe file")
                                .font(.title)
                        }
                        Spacer()
                    }
                }
            }
            
        }
        .gradientBackground
        .sheet(isPresented:$isAdding){
            RecipeAddView(isAdding: $isAdding, recipes: recipes)
        }
        
    }
}

#Preview {
    RecipeView(recipes: Recipes(), steps: RecipeSteps())
}
