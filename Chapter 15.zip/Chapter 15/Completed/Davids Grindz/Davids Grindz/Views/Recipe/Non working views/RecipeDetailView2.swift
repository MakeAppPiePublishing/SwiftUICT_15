//
//  RecipeDetailView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/2/25.
//

import SwiftUI

struct RecipeDetailView_02: View {
    @Binding var recipe:Recipe
    @Bindable var recipes:Recipes
    @State private var id:Int = -1
    @State private var name:String = ""
    @State private var yield:Double = 3.14159
    @State private var uom:UnitOfMeasure = .na
    @State private var category:IngredientCategory = .na
    @State private var isCommercial:Bool = true
    @State private var isEditing:Bool = false
    
    func refreshDisplayedRecipe(with recipe:Recipe){
        id = recipe.id
        name = recipe.name
        yield = recipe.yield
        uom = recipe.uom
        category = recipe.category
    }
    
    var body: some View {
        VStack{
            HStack{
                Spacer()
                Text(recipe.id,format:.number)
                Text(recipe.name)
            }
            HStack{
                Text(recipe.category.rawValue)
                Spacer()
                Text("Yield")
                Text(recipe.yield,format:.number.precision(.fractionLength(3)))
                Text(recipe.uom.rawValue)
            }
            //RecipeStepsView(recipeID: id, isCommercialRecipe: isCommercial)
        }
        .toolbar{
            ToolbarItemGroup(placement: .topBarTrailing) {
                
                Button{
                    isCommercial.toggle()
                }label:{
                    Image(systemName: isCommercial ? "building":"house")
                }.padding(.trailing,10)
                
                // Previous recipe Button
                Button{
                    recipe = recipes.previousRecipe(id: id)
                    refreshDisplayedRecipe(with: recipe)
                }label:{
                    Image(systemName:"chevron.backward")
                }
                
                //Next Recipe Button
                Button{
                    recipe = recipes.nextRecipe(id: id)
                    refreshDisplayedRecipe(with: recipe)
                }label:{
                    Image(systemName:"chevron.forward")
                }
                //toggle between commercial and home formats
                
                
                //Edit the recipe
                Button{
                    isEditing.toggle()
                } label: {
                    Image(systemName: isEditing ? "pencil.and.list.clipboard" : "text.rectangle.page")
                }
                
                
                //add a recipe
                Button{
                    
                }label:{
                    Image(systemName:"plus.rectangle")
                }
                
            }
        }
        .onChange(of: recipe) { oldValue, newValue in
            refreshDisplayedRecipe(with: newValue)
        }
    }
}

#Preview{
    RecipeDetailView_02(recipe: .constant(Recipes().table[2]), recipes: Recipes())
}
