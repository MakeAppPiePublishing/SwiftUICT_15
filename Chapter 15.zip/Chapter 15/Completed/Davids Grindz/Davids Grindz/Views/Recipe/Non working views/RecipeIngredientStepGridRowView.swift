//
//  RecipeIngredientStepGridRowView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/3/25.
//

import SwiftUI

struct RecipeIngredientStepGridRowView: View {
    @Binding var step:RecipeStep
    @State private var uom:UnitOfMeasure
    @State private var ingredientName:String
    init(step:Binding<RecipeStep>){
        //initialize arguments
        self._step = step
        // find the ingredient information for the step
        if let ingredient = Ingredients().table.first(where: {$0.id == step.itemCode.wrappedValue}){
            self.uom = ingredient.uom
            self.ingredientName = ingredient.itemName
        } else{
            self.uom = .na
            self.ingredientName = "Ingredient \(step.itemCode) not found"
        }
    }
    
    var body: some View {
        GridRow{
            Text(step.quantity,format:.number.precision(.fractionLength(3)))
                .gridCellAnchor(.trailing)
            Text(uom.rawValue)
                .gridCellAnchor(.leading)
            Text(ingredientName)
                .gridCellAnchor(.leading)
            Text(step.actions)
                .gridCellAnchor(.leading)

        }
        
    }
}

#Preview {
    Grid{
        RecipeIngredientStepGridRowView(step:.constant(RecipeSteps().table[1]))
    }
}
