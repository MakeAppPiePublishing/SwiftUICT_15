//
//  RecipeActionStepGridRowView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/3/25.
//

import SwiftUI

//struct RecipeActionStepGridRowView: View {
//    var step:RecipeStep
//    var body: some View {
//        GridRow{
//            Image(systemName:"app")
//                .gridCellAnchor(.leading)
//            Text(step.actions)
//                .gridCellColumns(2)
//                .gridCellAnchor(.leading)
//        }
//    }
//}
//
//#Preview {
//    Grid{
//        RecipeActionStepGridRowView(step:RecipeSteps().table[12])
//    }
//}
