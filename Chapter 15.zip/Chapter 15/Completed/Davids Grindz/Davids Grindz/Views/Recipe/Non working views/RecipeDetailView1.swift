//
//  RecipeView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/2/25.
//

//struct Recipe:Identifiable,Hashable,Equatable{
//    var id:Int
//    var name:String
//    var yield:Double
//    var uom:UnitOfMeasure
//    var category:IngredientCategory
//}

import SwiftUI

struct RecipeDetailView_01: View {
    @Bindable var recipes:Recipes
    @Bindable var steps:RecipeSteps
//    @State private var isEditing:Bool = false
//    @State private var isCommercial = false
    @State private var recipe:Recipe = .blank
    
    init(selectedRecipe:Recipe,recipes:Recipes,steps:RecipeSteps){
        self.recipe = selectedRecipe
        self.steps = steps
        self.recipes = recipes
        /// TODO:  what does this do? probabaly has to do with initilizaing from a computed property - but was suppsed to be intializing from something esle?
        let recipeID = recipe.id
        recipe.id = 0
        recipe.id = recipeID
    }
    
    var body: some View {
        
        VStack{
            HStack{
                Text("Recipe ID")
                Text(recipe.id,format:.number)
                TextStringInputField(label: "", value: $recipe.name)
                Spacer()
                Button{
                    recipe = recipes.nextRecipe(id: recipe.id)
                } label:{
                    Image(systemName:"chevron.forward")
                }
//                Button{
//                    isCommercial.toggle()
//                } label:{
//                    Image(systemName: isCommercial ? "building" : "house")
//                }
            }
            .font(.title)
            HStack{
                TextDoubleInputField(label: "Yield", number: $recipe.yield)
                UoMPicker(uom: $recipe.uom)
                Spacer()
                CategoryPicker(category: $recipe.category)
            }.font(.title2)
            RecipeStepsView(recipeID: $recipe.id,steps:steps)
        }
    }
}

#Preview {
    @Previewable @State var recipe = Recipes().table[1]
    @Previewable @State var recipes:Recipes = Recipes()
    @Previewable @State var steps:RecipeSteps = RecipeSteps()
    RecipeDetailView_01(selectedRecipe: recipe, recipes: recipes,steps:steps)
}
