//
//  RecipeStepRowView.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

//struct RecipeStep:Identifiable,Hashable,Equatable{
//    var recipeID:Int = -1
//    var row:Int = 0
//    var itemCode:Int = 0
//    var quantity:Double = 0.0
//    var actions:String
//    var id:Int{recipeID * 1000 + row}
//}


import SwiftUI

struct RecipeActionStepRowView: View {
    var step:RecipeStep
    var body: some View {
        HStack{
            Text(step.actions)
            Spacer()
        }
    }
}

#Preview {
    @Previewable @State var step = RecipeSteps().table[12]
    RecipeActionStepRowView(step:step)
}
