//
//  RecipeIngredientStepRow.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 4/1/25.
//

//struct RecipeStep:Identifiable,Hashable,Equatable{
//    var recipeID:Int = -1
//    var row:Int = 0
//    var itemCode:Int = 0
//    var quantity:Double = 0.0
//    var actions:String
//    var id:Int{recipeID * 1000 + row}
//}

import SwiftUI

struct RecipeIngredientStepRowView: View {
    @State var step:RecipeStep
    @State private var uom:UnitOfMeasure
    @State private var ingredientName:String
    init(step:RecipeStep){
        self.step = step
        let ingredient = Ingredients().table.first{$0.id == step.itemCode}
        
        // find the ingredient information for the step
        self.uom = ingredient?.uom ?? .na
        self.ingredientName = ingredient?.itemName ?? "Ingredient \(step.itemCode) not found"
    }
    
    var body: some View {
        HStack{
            Text(step.quantity,format:.number.precision(.fractionLength(3)))
            Text(uom.rawValue)
            Text(ingredientName)
            Text(step.actions)
            Spacer()
        }
        
    }
}

#Preview {
    @Previewable @State var step = RecipeSteps().table[2]
    RecipeIngredientStepRowView(step:step)
}
