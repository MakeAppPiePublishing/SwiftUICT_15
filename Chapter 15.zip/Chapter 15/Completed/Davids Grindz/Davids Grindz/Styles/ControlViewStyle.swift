//
//  ControlViewStyle.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

struct ControlViewStyle:ViewModifier{
    var label:String
    var isEditing:Bool
    func body(content: Content) -> some View {
        HStack(alignment: .center){
            if label != ""{
                Text(label)
                    .rightFixedStyle(width: 100)
                    .font(.headline)
            }
            content
                .disabled(!isEditing)
                .padding()
                .border(isEditing ? .black : .clear)
            if label != ""{
                Spacer()
            }
        }
    }
}

extension View{
    /// the style for the controls 
    func controlViewStyle(label:String,isEditing:Bool)-> some View{
        self.modifier(ControlViewStyle(label: label, isEditing: isEditing))
    }
}
