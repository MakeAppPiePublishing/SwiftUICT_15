//
//  Colors.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/23/25.
//

import SwiftUI

/// a Palette of colors to use in the app.
extension ShapeStyle where Self == Color {
    
    ///Light blue green  #C6EEFF
    static var sky:Color{Color(red:0.78,green:0.937,blue:1.0)}
    
    ///Medium Blue Green #5E86BF
    static var surf:Color{Color(red:0.37,green:0.527,blue:0.75)}
    
    /// Dark Blue #1F395F
    static var deep:Color{Color(red:0.125,green:0.227,blue:0.376)}
    
    /// Persimmon Red #E55E1A
    static var sunset:Color{Color(red:0.90,green:0.369,blue:0.102)}
    
    /// RYB Green #5BA23C
    static var palm:Color{Color(red:0.357,green:0.637,blue:0.239)}
}
/// A palm-sky-white gradient  background
struct GradientBackground: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(LinearGradient(stops:[
                Gradient.Stop(color: .palm.opacity(0.1), location: 0.05),
                Gradient.Stop(color: .sky, location: 0.15),
                Gradient.Stop(color: .white, location: 1.0)
            ], startPoint: .top, endPoint: .bottom))
    }
}

/// Background for sheets  of sky to white with `deep` for the tint color
struct SheetBackground:ViewModifier{
    func body(content:Content) -> some View {
        content
            .padding()
            .tint(.deep)
            .background(LinearGradient(colors: [.sky,.white], startPoint: .top, endPoint: .bottom))
    }
}

extension View{
    
    /// A palm-sky-white gradient  background
    var gradientBackground:some View{
        self.modifier(GradientBackground())
    }
    /// Background for sheets  of sky to white with `deep` for the tint color
    var sheetBackground:some View{
        self.modifier(SheetBackground())
    }
}
