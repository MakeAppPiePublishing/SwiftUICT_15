//
//  StyleSheet.swift
//  HuliPizza
//
//  Created by Steven Lipton on 2/21/25.
//

import SwiftUI


// - modifiers for consistency with the Huli Pizza app


/// Draw a surboard shape
struct Surfboard: Shape{
    func path(in rect:CGRect) -> Path{
        var radius:Double{rect.maxY - rect.midY}
        var path = Path()
        path.move(to:CGPoint(x:rect.minX,y:rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX - radius, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX - radius, y: rect.midY), radius: radius, startAngle: .degrees(-90), endAngle: .degrees(90), clockwise: false)
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        
        
        
        return path
    }
}

/// Make a background of `Surfboard` in `deep` color and `sky` foreground
struct SurfboardBackground:ViewModifier{
    func body(content:Content) -> some View{
            content
                .padding()
                .foregroundStyle(.sky)
                .background(.deep, in:Surfboard())
    }
}


/// Right justified title
///  - size adjusted for device
struct SurfboardTitle:ViewModifier{
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    func body(content:Content) -> some View{
        HStack{
            Spacer()
            content
                .font(
                    verticalSizeClass == .regular &&
                    horizontalSizeClass == .regular
                    ? .largeTitle : .title
                )
        }
    }
}

/// Standard button style with a specified background color.
struct AppButtonStyleModifier:ViewModifier {
    var backgroundColor:Color
    
    var foregroundColor:Color{
        switch backgroundColor{
        case .sky,.white,.clear :return .deep
        default : return .sky
        }
    }
    func body(content:Content) -> some View {
        content
            .font(.title3).bold()
            .padding([.leading,.trailing], 15)
            .padding([.top,.bottom], 8)
            .background(backgroundColor)
            .foregroundStyle(foregroundColor)
            .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}


/// Black border around a view
struct TextFieldBorder:ViewModifier{
    func body(content:Content) -> some View {
        content
            .padding(4)
            .border(.black)
    }
}


/// Embed a view in a label of all uppercase. Used for all field titles
struct InputTitleLabelStyle:ViewModifier{
    var label:String
    func body(content:Content) -> some View {
        VStack(alignment:.leading){
            Text(label)
                .font(.caption2)
                .fontWeight(.medium)
                .textCase(.uppercase)
                .foregroundStyle(.deep)
            content
                .padding(.leading,5)
        }
        .padding(.top,10)
    }
}




/// A style for selection of row feedback
///  - will scale for devices
struct StepSelectionStyleModifier:ViewModifier{
    
    var displayRowID:Int
    var stepID:Int
    @Environment(\.verticalSizeClass) var verticalSizeClass
    @Environment(\.horizontalSizeClass) var horizontalSizeClass
    var scaledFont:Font{
        if
            horizontalSizeClass == .compact  || verticalSizeClass == .compact{
            Font.system(size: 18)
        }else{
            Font.system(size: 24)
        }
    }
    func body(content:Content) -> some View{
        content
            .font(scaledFont)
        .fontWeight(displayRowID == stepID ? .bold : .regular)
        .foregroundStyle(displayRowID == stepID ? .surf : .deep)
    }
}

/// a style for rows without selection
/// - will scale for devices
struct RowStyleModifier:ViewModifier{
    @Environment(\.verticalSizeClass) var verticalSizeClass
    @Environment(\.horizontalSizeClass) var horizontalSizeClass
    var scaledFont:Font{
        if
            horizontalSizeClass == .compact  || verticalSizeClass == .compact{
            Font.system(size: 18)
        }else{
            Font.system(size: 24)
        }
    }
    func body(content:Content) -> some View{
        content
            .font(scaledFont)
        .fontWeight( .regular)
        .foregroundStyle(.deep)
    }
}

/*
// -- Not used: legacy code from development


struct ListRowStyleModifier:ViewModifier{
    var imageID:Int
    
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    
    func body(content:Content) -> some View{
        ZStack{
            Surfboard()
                .stroke(Color.surf)
                .fill(Color.clear)
            HStack{
                if let image = UIImage(named: "\(imageID)_sm"){
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: verticalSizeClass == .compact ? 40: (horizontalSizeClass == .regular  ? 125 : 70))
                } else {
                    Image("surfboard_sm")
                        .resizable()
                        .scaledToFit()
                        .frame(height: verticalSizeClass == .compact ? 40: (horizontalSizeClass == .regular  ? 125 : 70))
                }
                content
                    .font(verticalSizeClass == .regular && horizontalSizeClass == .regular ? .title : .body)
                    .padding([.top,.bottom],4)
                    .padding([.leading,.trailing],12)
                    .background(.clear)
                    .foregroundStyle(.primary)
            }
        }
    }
}



struct StatusBarStyle:ViewModifier{
    func body(content:Content) -> some View {
        content
            .foregroundStyle(.sky)
            .font(.title2)
            .padding(3)
            .background(.deep,in:RoundedRectangle(cornerRadius: 3))
    }
}

struct InputItemStyleModifier:ViewModifier{
    func body(content:Content) -> some View{
        content
            .padding(8)
            .foregroundStyle(.primary)
            .background(.sky,in:RoundedRectangle(cornerRadius:10))
            .border(.deep)
    }
}
*/

extension View{
    
    var textFieldBorder: some View{
        self.modifier(TextFieldBorder())
    }
    

    var surfboardBackground:some View{
        self.modifier(SurfboardBackground())
        }
    var surfboardTitle:some View{
        self.modifier(SurfboardTitle())
        }
    
    var rowStyleModifier:some View{
        self.modifier(RowStyleModifier())
    }

    func appButtonStyleModifier(backgroundColor:Color) -> some View{
        self.modifier(AppButtonStyleModifier(backgroundColor: backgroundColor))
    }
 
    func inputTitleLabelStyle(label:String) -> some View{
        self.modifier(InputTitleLabelStyle(label:label))
    }
    
    func stepSelectionStyleModifier(displayRowID:Int,stepID:Int)-> some View{
        self.modifier(StepSelectionStyleModifier(displayRowID: displayRowID, stepID: stepID))
    }
    
    
    
//
//    var statusBarStyle:some View{
//        self.modifier(StatusBarStyle())
//    }
//
//
//    func listRowStyleModifier(imageID:Int) -> some View{
//        self.modifier(ListRowStyleModifier(imageID: imageID))
//    }
//
//
//    var inputItemStyleModifier:some View{
//        self.modifier(InputItemStyleModifier())
//    }
//
}
