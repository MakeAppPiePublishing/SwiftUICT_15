//
//  FixedStylesStyle.swift
//  Davids Grindz
//
//  Created by Steven Lipton on 3/30/25.
//
//  A series of fixed styles for text alignment at a specified width.

import SwiftUI
///Left jusify view of fixed width
/// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
struct LeftFixedStyle:ViewModifier{
    var width:CGFloat?
    func body(content:Content)-> some View{
        HStack{
            content
            Spacer()
        }
        .frame(width:width)
    }
}
///Right jusify view of fixed width
/// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
struct RightFixedStyle:ViewModifier{
    var width:CGFloat?
    func body(content:Content)-> some View{
        HStack{
            Spacer()
            content
        }
        .frame(width:width)
    }
}
///Center jusify view of fixed width
/// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
struct CenterFixedStyle:ViewModifier{
    var width:CGFloat?
    func body(content:Content)-> some View{
        HStack{
            Spacer()
            content
            Spacer()
        }
        .frame(width:width)
    }
}

extension View{
    
    /// A modifier to use a fixed width style view left justified in its space
    /// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
    func leftFixedStyle(width:CGFloat? = nil) -> some View{
        self.modifier(LeftFixedStyle(width:width) )
    }
    /// A modifier to use a fixed width style view right justified in its space
    /// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
    func rightFixedStyle(width:CGFloat? = nil) -> some View{
        self.modifier(RightFixedStyle(width:width) )
    }
    
    /// A modifier to use a fixed width style view center  justified in its space
    /// - Parameter width:`CGFloat? = nil` fixed width view unless `nil`
    func centerFixedStyle(width:CGFloat? = nil) -> some View{
        self.modifier(CenterFixedStyle(width:width) )
    }
    
    
}
